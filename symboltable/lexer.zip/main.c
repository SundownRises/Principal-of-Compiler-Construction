#include <stdio.h>

extern int yyparse();
extern void yyerror(const char *s);

int main(void) {
    return yyparse();
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}
